import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Services from "./components/Services";
import Platforms from "./components/Platforms";
import Process from "./components/Process";
import Pricing from "./components/Pricing";
import CaseStudies from "./components/CaseStudies";
import Testimonials from "./components/Testimonials";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import { motion, AnimatePresence, useScroll, useSpring } from "motion/react";
import { useState, useEffect } from "react";

export default function App() {
  const [activeTab, setActiveTab] = useState("Home");
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  // Scroll to top on tab change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeTab]);

  const renderContent = () => {
    switch (activeTab) {
      case "Home":
        return <Hero onViewServices={() => setActiveTab("Services")} />;
      case "Services":
        return (
          <div>
            <Services />
            <Process />
          </div>
        );
      case "Ad Management":
        return <Platforms />;
      case "Pricing":
        return <Pricing />;
      case "Case Studies":
        return (
          <div>
            <CaseStudies />
            <Testimonials />
          </div>
        );
      case "About":
        return (
          <div className="py-32 max-w-7xl mx-auto px-6 text-center">
            <h2 className="text-5xl font-bold mb-8">About Social Sage</h2>
            <p className="text-brand-muted text-xl max-w-3xl mx-auto leading-relaxed">
              We are a team of digital growth experts dedicated to helping modern brands scale. Our mission is to bridge the gap between data and creativity.
            </p>
          </div>
        );
      case "Blog":
        return (
          <div className="py-32 max-w-7xl mx-auto px-6 text-center">
            <h2 className="text-5xl font-bold mb-8">Marketing Insights</h2>
            <p className="text-brand-muted text-xl max-w-3xl mx-auto leading-relaxed">
              Our latest thoughts on digital marketing, advertising, and brand growth. Coming soon.
            </p>
          </div>
        );
      case "Contact":
        return <CTA />;
      default:
        return <Hero onViewServices={() => setActiveTab("Services")} />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-bg text-white selection:bg-white selection:text-brand-bg flex flex-col">
      {/* Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-white z-[60] origin-left"
        style={{ scaleX }}
      />

      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  );
}
