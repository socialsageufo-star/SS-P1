import { motion } from "motion/react";
import { ArrowRight, Play } from "lucide-react";

export default function Hero({ onViewServices }: { onViewServices: () => void }) {
  return (
    <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-gradient-hero -z-10" />
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-white/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-white/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold tracking-widest uppercase mb-6 text-brand-muted">
            The Future of Digital Growth
          </span>
          <h1 className="font-display text-5xl lg:text-8xl font-bold tracking-tight leading-[1.1] mb-8 max-w-4xl mx-auto">
            Scale Your Brand With <span className="text-gradient">Smarter Marketing</span>
          </h1>
          <p className="text-lg lg:text-xl text-brand-muted max-w-2xl mx-auto mb-10 leading-relaxed">
            We combine data-driven strategies with creative excellence to help modern brands dominate their niche and achieve exponential growth.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={onViewServices}
              className="w-full sm:w-auto bg-white text-brand-bg px-10 py-5 rounded-full text-lg font-bold flex items-center justify-center gap-3 hover:bg-brand-accent transition-all transform hover:scale-105 active:scale-95"
            >
              View Services <Play size={20} fill="currentColor" />
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-20 relative"
        >
          <div className="glass rounded-3xl p-4 lg:p-6 aspect-video max-w-5xl mx-auto overflow-hidden shadow-2xl border-white/10">
            <img 
              src="https://picsum.photos/seed/marketing-dashboard/1200/675" 
              alt="Social Sage Dashboard" 
              className="w-full h-full object-cover rounded-2xl opacity-80"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-bg/80 via-transparent to-transparent" />
          </div>
          
          {/* Floating stats */}
          <div className="absolute -bottom-6 -left-6 lg:left-12 glass p-6 rounded-2xl hidden md:block">
            <div className="text-3xl font-bold font-display">+240%</div>
            <div className="text-xs text-brand-muted uppercase tracking-wider">Avg. ROAS Increase</div>
          </div>
          <div className="absolute -top-6 -right-6 lg:right-12 glass p-6 rounded-2xl hidden md:block">
            <div className="text-3xl font-bold font-display">1.2M+</div>
            <div className="text-xs text-brand-muted uppercase tracking-wider">Leads Generated</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
