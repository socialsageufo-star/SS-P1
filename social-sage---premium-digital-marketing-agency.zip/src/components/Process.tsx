import { motion } from "motion/react";

const steps = [
  {
    number: "01",
    title: "Audit",
    description: "We analyze your current digital footprint, competitors, and market opportunities to find the gaps.",
  },
  {
    number: "02",
    title: "Strategy",
    description: "Our team develops a comprehensive roadmap tailored to your specific growth objectives.",
  },
  {
    number: "03",
    title: "Launch",
    description: "We deploy high-impact campaigns across selected channels with precision execution.",
  },
  {
    number: "04",
    title: "Optimize",
    description: "Continuous monitoring and A/B testing to refine messaging and maximize performance.",
  },
  {
    number: "05",
    title: "Scale",
    description: "Once we find the winning formula, we aggressively scale your budget to drive massive growth.",
  },
];

export default function Process() {
  return (
    <section id="process" className="py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="font-display text-4xl lg:text-5xl font-bold mb-6">Our Proven Process</h2>
          <p className="text-brand-muted max-w-2xl mx-auto text-lg">
            A systematic approach to digital growth that removes guesswork and delivers predictable results.
          </p>
        </div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute top-1/2 left-0 w-full h-px bg-white/10 hidden lg:block -translate-y-1/2" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-4 relative z-10">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex flex-col items-center lg:items-start text-center lg:text-left group"
              >
                <div className="w-16 h-16 rounded-full bg-brand-card border border-white/10 flex items-center justify-center mb-8 group-hover:bg-white group-hover:text-brand-bg transition-all duration-500 relative">
                  <span className="text-xl font-bold font-display">{step.number}</span>
                  {/* Pulse effect */}
                  <div className="absolute inset-0 rounded-full bg-white/20 animate-ping opacity-0 group-hover:opacity-100" />
                </div>
                <h3 className="text-2xl font-bold mb-4">{step.title}</h3>
                <p className="text-brand-muted text-sm leading-relaxed">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
