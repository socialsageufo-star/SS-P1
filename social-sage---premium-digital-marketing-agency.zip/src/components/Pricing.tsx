import { motion } from "motion/react";
import { Check } from "lucide-react";

const plans = [
  {
    name: "Starter",
    price: "$100",
    description: "Perfect for small businesses looking to establish their presence.",
    features: [
      "2 Social Platforms",
      "Basic Ad Management",
      "Monthly Strategy Call",
      "Standard Reporting",
      "Email Support",
    ],
    cta: "Start Now",
    popular: false,
  },
  {
    name: "Growth",
    price: "$200",
    description: "Ideal for growing brands ready to scale their customer base.",
    features: [
      "4 Social Platforms",
      "Advanced Ad Management",
      "Bi-Weekly Strategy Calls",
      "Custom Content Strategy",
      "Priority Support",
      "Performance Dashboard",
    ],
    cta: "Scale Now",
    popular: true,
  },
  {
    name: "Pro",
    price: "$500",
    description: "Comprehensive solution for established brands dominating their niche.",
    features: [
      "All Social Platforms",
      "Omnichannel Ad Strategy",
      "Weekly Strategy Calls",
      "Full Content Production",
      "Dedicated Account Manager",
      "Advanced Analytics",
      "CRO Optimization",
    ],
    cta: "Go Pro",
    popular: false,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "Tailored strategies for large-scale operations and global brands.",
    features: [
      "Unlimited Platforms",
      "Global Campaign Mgmt",
      "24/7 Dedicated Support",
      "White-Glove Service",
      "Custom API Integrations",
      "On-Site Consulting",
    ],
    cta: "Contact Us",
    popular: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-24 lg:py-32 bg-brand-card/20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="font-display text-4xl lg:text-5xl font-bold mb-6">Transparent Pricing</h2>
          <p className="text-brand-muted max-w-2xl mx-auto text-lg">
            Choose the plan that fits your current stage of growth. No hidden fees, just results.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`relative p-8 rounded-4xl border ${
                plan.popular ? "bg-white border-white" : "bg-brand-card border-white/5"
              } flex flex-col h-full`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-brand-bg text-white text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full border border-white/10">
                  Most Popular
                </div>
              )}
              
              <div className="mb-8">
                <h3 className={`text-xl font-bold mb-2 ${plan.popular ? "text-brand-bg" : "text-white"}`}>
                  {plan.name}
                </h3>
                <div className="flex items-baseline gap-1 mb-4">
                  <span className={`text-4xl font-bold font-display ${plan.popular ? "text-brand-bg" : "text-white"}`}>
                    {plan.price}
                  </span>
                  {plan.price !== "Custom" && (
                    <span className={`text-sm ${plan.popular ? "text-brand-bg/60" : "text-brand-muted"}`}>/mo</span>
                  )}
                </div>
                <p className={`text-sm leading-relaxed ${plan.popular ? "text-brand-bg/70" : "text-brand-muted"}`}>
                  {plan.description}
                </p>
              </div>

              <div className="flex-grow space-y-4 mb-10">
                {plan.features.map((feature) => (
                  <div key={feature} className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                      plan.popular ? "bg-brand-bg/10 text-brand-bg" : "bg-white/10 text-white"
                    }`}>
                      <Check size={12} />
                    </div>
                    <span className={`text-sm ${plan.popular ? "text-brand-bg/80" : "text-brand-muted"}`}>
                      {feature}
                    </span>
                  </div>
                ))}
              </div>

              <button className={`w-full py-4 rounded-full font-bold transition-all transform hover:scale-[1.02] active:scale-95 ${
                plan.popular 
                  ? "bg-brand-bg text-white hover:bg-black" 
                  : "bg-white/5 text-white border border-white/10 hover:bg-white/10"
              }`}>
                {plan.cta}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
