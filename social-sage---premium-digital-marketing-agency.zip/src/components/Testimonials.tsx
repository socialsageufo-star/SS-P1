import { motion } from "motion/react";
import { Quote } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Jenkins",
    role: "CEO, Luxe Living",
    quote: "Social Sage transformed our business. Their data-driven approach and creative excellence helped us scale to $1M/mo in record time. Truly world-class.",
    image: "https://i.pravatar.cc/150?u=sarah",
  },
  {
    name: "Michael Chen",
    role: "Founder, TechFlow",
    quote: "The best marketing agency we've ever worked with. They don't just run ads; they understand our brand and our customers. Our ROAS has never been higher.",
    image: "https://i.pravatar.cc/150?u=michael",
  },
  {
    name: "Emily Rodriguez",
    role: "Marketing Director, GlowUp",
    quote: "Their content strategy is unmatched. Our engagement rates have tripled since we started working with them. They're a true partner in our growth.",
    image: "https://i.pravatar.cc/150?u=emily",
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 lg:py-32 bg-brand-card/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="font-display text-4xl lg:text-5xl font-bold mb-6">What Our Clients Say</h2>
          <p className="text-brand-muted max-w-2xl mx-auto text-lg">
            Don't just take our word for it. Hear from the brands we've helped scale to new heights.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="glass p-10 rounded-4xl border border-white/5 flex flex-col justify-between relative group"
            >
              <div className="absolute top-6 right-8 text-white/5 group-hover:text-white/10 transition-colors duration-500">
                <Quote size={64} fill="currentColor" />
              </div>
              
              <div className="relative z-10">
                <p className="text-lg text-brand-muted leading-relaxed mb-10 italic">
                  "{testimonial.quote}"
                </p>
              </div>
              
              <div className="flex items-center gap-4 relative z-10">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name} 
                  className="w-12 h-12 rounded-full object-cover border-2 border-white/10"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-bold">{testimonial.name}</h4>
                  <p className="text-xs text-brand-muted uppercase tracking-widest">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
