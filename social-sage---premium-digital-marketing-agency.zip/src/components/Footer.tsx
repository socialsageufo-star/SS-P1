import { Facebook, Instagram, Twitter, Github, ArrowUpRight } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="pt-24 pb-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-24 mb-20">
          {/* Brand Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-8">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-brand-bg rounded-sm rotate-45" />
              </div>
              <span className="font-display font-bold text-xl tracking-tight">Social Sage</span>
            </div>
            <p className="text-brand-muted leading-relaxed mb-8">
              Helping modern brands scale through data-driven marketing and creative excellence.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-white hover:text-brand-bg transition-all">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-white hover:text-brand-bg transition-all">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-white hover:text-brand-bg transition-all">
                <Twitter size={18} />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-bold mb-8 uppercase tracking-widest text-xs text-brand-muted">Navigation</h4>
            <ul className="space-y-4">
              {["Home", "Services", "Ad Management", "Pricing", "Case Studies", "About", "Blog", "Contact"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-brand-muted hover:text-white transition-colors flex items-center gap-1 group">
                    {item} <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold mb-8 uppercase tracking-widest text-xs text-brand-muted">Services</h4>
            <ul className="space-y-4">
              {["Social Media Marketing", "Paid Ads Management", "Content Strategy", "Lead Generation", "Analytics & Optimization"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-brand-muted hover:text-white transition-colors flex items-center gap-1 group">
                    {item} <ArrowUpRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-bold mb-8 uppercase tracking-widest text-xs text-brand-muted">Newsletter</h4>
            <p className="text-brand-muted text-sm mb-6">
              Subscribe to our newsletter for the latest marketing insights and growth strategies.
            </p>
            <div className="flex flex-col gap-3">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="bg-white/5 border border-white/10 rounded-full px-6 py-3 text-sm focus:outline-none focus:border-white/30 transition-all"
              />
              <button className="bg-white text-brand-bg px-6 py-3 rounded-full text-sm font-bold hover:bg-brand-accent transition-all">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-brand-muted text-sm">
            © {currentYear} Social Sage. All rights reserved.
          </p>
          <div className="flex items-center gap-8">
            <a href="#" className="text-brand-muted hover:text-white text-sm transition-colors">Privacy Policy</a>
            <a href="#" className="text-brand-muted hover:text-white text-sm transition-colors">Terms of Service</a>
            <a href="#" className="text-brand-muted hover:text-white text-sm transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
