import { motion } from "motion/react";
import { Facebook, Instagram, Search, Music } from "lucide-react";

const platforms = [
  { name: "Facebook Ads", icon: <Facebook size={32} />, color: "bg-blue-600/20 text-blue-400" },
  { name: "Instagram Ads", icon: <Instagram size={32} />, color: "bg-pink-600/20 text-pink-400" },
  { name: "Google Ads", icon: <Search size={32} />, color: "bg-red-600/20 text-red-400" },
  { name: "TikTok Ads", icon: <Music size={32} />, color: "bg-cyan-600/20 text-cyan-400" },
];

export default function Platforms() {
  return (
    <section id="platforms" className="py-24 lg:py-32 bg-brand-card/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-24">
          <div className="lg:w-1/2">
            <h2 className="font-display text-4xl lg:text-5xl font-bold mb-8 leading-tight">
              Dominate Every <span className="text-gradient">Platform</span>
            </h2>
            <p className="text-brand-muted text-lg mb-10 leading-relaxed">
              We don't just run ads; we craft platform-specific experiences that capture attention and drive action. Our experts stay ahead of algorithm changes to ensure your brand always wins.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mt-1">
                  <div className="w-2 h-2 rounded-full bg-white" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Creative Optimization</h4>
                  <p className="text-sm text-brand-muted">Tailored visuals for each platform's unique audience.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center mt-1">
                  <div className="w-2 h-2 rounded-full bg-white" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Precision Targeting</h4>
                  <p className="text-sm text-brand-muted">Reaching the exact people who need your product.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 grid grid-cols-2 gap-4 lg:gap-6">
            {platforms.map((platform, index) => (
              <motion.div
                key={platform.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className={`p-8 rounded-3xl flex flex-col items-center justify-center gap-4 text-center border border-white/5 ${platform.color} glass`}
              >
                {platform.icon}
                <span className="font-bold text-sm tracking-wide uppercase">{platform.name}</span>
              </motion.div>
            ))}
            <div className="p-8 rounded-3xl flex flex-col items-center justify-center gap-4 text-center border border-white/5 bg-white/5 text-white glass">
              <div className="text-3xl font-bold font-display">+More</div>
              <span className="font-bold text-sm tracking-wide uppercase">Custom Platforms</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
