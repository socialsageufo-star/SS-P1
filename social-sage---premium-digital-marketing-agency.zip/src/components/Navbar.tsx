import { motion } from "motion/react";
import { Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

export default function Navbar({ activeTab, setActiveTab }: { activeTab: string, setActiveTab: (tab: string) => void }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const menuItems = [
    { name: "Home", id: "Home" },
    { name: "Services", id: "Services" },
    { name: "Ad Management", id: "Ad Management" },
    { name: "Pricing", id: "Pricing" },
    { name: "Case Studies", id: "Case Studies" },
    { name: "About", id: "About" },
    { name: "Blog", id: "Blog" },
    { name: "Contact", id: "Contact" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4 ${
        isScrolled ? "glass mt-4 mx-6 rounded-full" : "bg-transparent mt-0 mx-0"
      }`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => setActiveTab("Home")}
        >
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
            <div className="w-4 h-4 bg-brand-bg rounded-sm rotate-45" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight">Social Sage</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center gap-8">
          {menuItems.map((item) => (
            <button
              key={item.name}
              onClick={() => setActiveTab(item.id)}
              className={`text-sm font-medium transition-colors ${
                activeTab === item.id ? "text-white" : "text-brand-muted hover:text-white"
              }`}
            >
              {item.name}
            </button>
          ))}
        </div>

        <div className="hidden lg:block">
          <button 
            onClick={() => setActiveTab("Contact")}
            className="bg-white text-brand-bg px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-brand-accent transition-all transform hover:scale-105 active:scale-95"
          >
            Get a Free Strategy Call
          </button>
        </div>

        {/* Mobile Toggle */}
        <button
          className="lg:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 right-0 mt-4 mx-6 glass rounded-2xl p-6 lg:hidden"
        >
          <div className="flex flex-col gap-4">
            {menuItems.map((item) => (
              <button
                key={item.name}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`text-lg font-medium text-left transition-colors ${
                  activeTab === item.id ? "text-white" : "text-brand-muted hover:text-white"
                }`}
              >
                {item.name}
              </button>
            ))}
            <button 
              onClick={() => {
                setActiveTab("Contact");
                setIsMobileMenuOpen(false);
              }}
              className="bg-white text-brand-bg px-6 py-3 rounded-xl text-sm font-semibold mt-2"
            >
              Get a Free Strategy Call
            </button>
          </div>
        </motion.div>
      )}
    </nav>
  );
}
