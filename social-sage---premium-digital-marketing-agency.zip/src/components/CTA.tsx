import { motion } from "motion/react";
import { Calendar, ArrowRight } from "lucide-react";

export default function CTA() {
  return (
    <section id="contact" className="py-24 lg:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-gradient-hero -z-10" />
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-white/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-white/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="glass p-12 lg:p-24 rounded-4xl border border-white/10 text-center relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
          
          <div className="relative z-10">
            <h2 className="font-display text-4xl lg:text-7xl font-bold mb-8 leading-tight tracking-tight">
              Ready to <span className="text-gradient">Grow Your Brand?</span>
            </h2>
            <p className="text-brand-muted text-lg lg:text-xl max-w-2xl mx-auto mb-12 leading-relaxed">
              Book a free strategy call today and let's build a roadmap to scale your business to new heights. No pressure, just results.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <button className="w-full sm:w-auto bg-white text-brand-bg px-10 py-5 rounded-full text-lg font-bold flex items-center justify-center gap-3 hover:bg-brand-accent transition-all transform hover:scale-105 active:scale-95">
                <Calendar size={20} /> Book a Strategy Call
              </button>
              <button className="w-full sm:w-auto glass px-10 py-5 rounded-full text-lg font-bold flex items-center justify-center gap-3 hover:bg-white/10 transition-all">
                View Case Studies <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
