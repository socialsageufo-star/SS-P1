import { motion } from "motion/react";
import { Share2, Target, PenTool, Zap, BarChart3 } from "lucide-react";

const services = [
  {
    title: "Social Media Marketing",
    description: "Building community and engagement through strategic content and platform management.",
    icon: <Share2 className="text-white" size={24} />,
  },
  {
    title: "Paid Ads Management",
    description: "High-converting campaigns across Meta, Google, and TikTok optimized for maximum ROI.",
    icon: <Target className="text-white" size={24} />,
  },
  {
    title: "Content Strategy",
    description: "Crafting compelling narratives and visual assets that resonate with your target audience.",
    icon: <PenTool className="text-white" size={24} />,
  },
  {
    title: "Lead Generation",
    description: "Systematic approaches to filling your sales funnel with high-quality, ready-to-buy prospects.",
    icon: <Zap className="text-white" size={24} />,
  },
  {
    title: "Analytics & Optimization",
    description: "Deep-dive data analysis to continuously refine and improve campaign performance.",
    icon: <BarChart3 className="text-white" size={24} />,
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 lg:mb-24">
          <h2 className="font-display text-4xl lg:text-5xl font-bold mb-6">Our Expertise</h2>
          <p className="text-brand-muted max-w-2xl mx-auto text-lg">
            We provide a full suite of digital marketing services designed to scale your business in the modern digital landscape.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-brand-card p-8 lg:p-10 rounded-3xl border border-white/5 hover:border-white/10 transition-all group"
            >
              <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-white group-hover:text-brand-bg transition-colors duration-300">
                {service.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
              <p className="text-brand-muted leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
          
          {/* Special CTA Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="bg-white p-8 lg:p-10 rounded-3xl flex flex-col justify-between items-start group cursor-pointer"
          >
            <div>
              <h3 className="text-brand-bg text-2xl font-bold mb-4">Need a custom strategy?</h3>
              <p className="text-brand-bg/70 leading-relaxed mb-8">
                Every brand is unique. Let's build a tailored plan that fits your specific goals and budget.
              </p>
            </div>
            <button className="text-brand-bg font-bold flex items-center gap-2 group-hover:gap-4 transition-all">
              Book a Call <Share2 size={18} />
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
