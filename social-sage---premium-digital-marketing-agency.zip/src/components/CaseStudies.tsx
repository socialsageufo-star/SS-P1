import { motion } from "motion/react";
import { TrendingUp, Users, DollarSign } from "lucide-react";

const stats = [
  {
    label: "ROAS Increase",
    value: "204%",
    icon: <TrendingUp className="text-white" size={24} />,
    description: "Average return on ad spend across our client portfolio.",
  },
  {
    label: "Leads Generated",
    value: "1.2M+",
    icon: <Users className="text-white" size={24} />,
    description: "High-quality leads delivered to our clients in the last 12 months.",
  },
  {
    label: "Revenue Growth",
    value: "$10,000+",
    icon: <DollarSign className="text-white" size={24} />,
    description: "Direct revenue attributed to our marketing campaigns.",
  },
];

export default function CaseStudies() {
  return (
    <section id="case-studies" className="py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-end justify-between gap-8 mb-20">
          <div className="lg:w-2/3">
            <h2 className="font-display text-4xl lg:text-5xl font-bold mb-6">Real Results, <span className="text-gradient">Real Growth</span></h2>
            <p className="text-brand-muted text-lg max-w-2xl leading-relaxed">
              We don't just promise growth; we deliver it. Our data-driven approach has helped brands across industries achieve record-breaking results.
            </p>
          </div>
          <button className="glass px-8 py-4 rounded-full font-bold hover:bg-white/10 transition-all">
            View All Case Studies
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-brand-card p-10 rounded-4xl border border-white/5 relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:bg-white/10 transition-all duration-500" />
              
              <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center mb-8">
                {stat.icon}
              </div>
              
              <div className="text-5xl lg:text-6xl font-bold font-display mb-4 tracking-tight">
                {stat.value}
              </div>
              <h3 className="text-xl font-bold mb-4">{stat.label}</h3>
              <p className="text-brand-muted leading-relaxed">
                {stat.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Featured Case Study */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 glass p-8 lg:p-12 rounded-4xl flex flex-col lg:flex-row items-center gap-12"
        >
          <div className="lg:w-1/2">
            <img 
              src="https://picsum.photos/seed/case-study/800/600" 
              alt="Case Study" 
              className="w-full h-full object-cover rounded-3xl"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="lg:w-1/2">
            <span className="text-xs font-bold uppercase tracking-widest text-brand-muted mb-4 block">E-commerce Case Study</span>
            <h3 className="text-3xl font-bold mb-6">How "Luxe Living" Scaled to $1M/mo in 6 Months</h3>
            <p className="text-brand-muted mb-8 leading-relaxed">
              By implementing our omnichannel strategy and creative optimization framework, Luxe Living saw a 4.5x increase in conversion rate and a 300% growth in organic traffic.
            </p>
            <div className="grid grid-cols-2 gap-8 mb-10">
              <div>
                <div className="text-2xl font-bold font-display">8.4x</div>
                <div className="text-xs text-brand-muted uppercase tracking-wider">ROAS</div>
              </div>
              <div>
                <div className="text-2xl font-bold font-display">+420%</div>
                <div className="text-xs text-brand-muted uppercase tracking-wider">Revenue</div>
              </div>
            </div>
            <button className="bg-white text-brand-bg px-8 py-4 rounded-full font-bold hover:bg-brand-accent transition-all">
              Read Full Story
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
